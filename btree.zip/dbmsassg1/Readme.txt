After compiling using "gcc sample.c"

Test it by giving input file name as a command line argument

Like this "./a.out input.txt"



  
