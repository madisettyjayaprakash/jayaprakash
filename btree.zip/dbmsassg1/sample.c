#include<stdio.h>
#include<stdlib.h>
#include<string.h>

  int order;
  struct array1{
    int id;
    char name[1000];
  };
  struct node {
    int n; 
    struct array1 keysarr[1000]; 
    struct node *pointers[1000]; 
   }*begin=NULL;

   enum SoK { Alreadypresent,nokeyfound,triumph,key_insert,Mergecase };

   int locate(int key, struct array1 *array_keys, int n){

      int pos=0;
      while (pos < n && key >array_keys[pos].id)
                    pos++;
   
      return pos;}


enum SoK ins(struct node *potr, int key, int *upKey,struct node **nodejs,char c[],char d[]){

      struct node *nptr, *lptr;
      enum SoK value;
      int pos, i, n,spos,newKey, lastKey;
      char lstr[100],nstr[100];
   
    if (potr == NULL){
       *nodejs = NULL;
       *upKey = key;
       strcpy(d,c);
       return key_insert;}
    
    n = potr->n;
    pos = locate(key, potr->keysarr, n);
    
    if (pos < n && key == potr->keysarr[pos].id)
            return Alreadypresent;
            
    value = ins(potr->pointers[pos], key, &newKey, &nptr,c,nstr);
    
    if (value != key_insert)
        return value;
    
    if (n < order - 1){
            pos = locate(newKey, potr->keysarr, n);
        
        for (i=n; i>pos; i--){
            potr->keysarr[i].id = potr->keysarr[i-1].id;
            strcpy(potr->keysarr[i].name, potr->keysarr[i-1].name);
            potr->pointers[i+1] = potr->pointers[i];}
        
        potr->keysarr[pos].id = newKey;
        
        strcpy( potr->keysarr[pos].name ,nstr);
        
        potr->pointers[pos+1] = nptr;
        
        ++potr->n; 
        
        
   return triumph;}
    
    
    if (pos == order - 1){
            lastKey = newKey;
            
            strcpy(lstr,nstr);
        
            lptr = nptr;}
    
    else {
    
        lastKey = potr->keysarr[order-2].id;
        strcpy(lstr,potr->keysarr[order-2].name);
        lptr = potr->pointers[order-1];
            for (i=order-2; i>pos; i--){
        
              potr->keysarr[i].id = potr->keysarr[i-1].id;
              strcpy( potr->keysarr[i].name, potr->keysarr[i-1].name);
              potr->pointers[i+1] = potr->pointers[i];}
            
        
        potr->keysarr[pos].id = newKey;
        strcpy(potr->keysarr[pos].name, nstr);
        potr->pointers[pos+1] = nptr;}
    
    spos = (order - 1)/2;
    
    (*upKey) = potr->keysarr[spos].id;
    
     strcpy(d,potr->keysarr[spos].name);
    (*nodejs)=malloc(sizeof(struct node));
    potr->n = spos;
    
    (*nodejs)->n = order-1-spos;
    
    for (i=0; i < (*nodejs)->n; i++){
    
        (*nodejs)->pointers[i] = potr->pointers[i + spos + 1];
              if(i < (*nodejs)->n - 1){
                   (*nodejs)->keysarr[i].id = potr->keysarr[i + spos + 1].id;
                   strcpy((*nodejs)->keysarr[i].name, potr->keysarr[i + spos + 1].name);}
            
              else{
                   (*nodejs)->keysarr[i].id = lastKey;
                   strcpy((*nodejs)->keysarr[i].name, lstr); }}
           
    (*nodejs)->pointers[(*nodejs)->n] = lptr;
    
    return key_insert;
}


void insert(int key,char c[])
{
    
    struct node *nodejs;
    enum SoK value;
    int upKey;
    char d[100];
            
    value = ins(begin, key, &upKey, &nodejs,c,d);
       if (value == Alreadypresent)
              printf("Key=%d is already available\n",key);
    if (value == key_insert){
    
          struct node *uproot = begin;
          begin=malloc(sizeof(struct node));
          begin->n = 1;
          
          begin->keysarr[0].id = upKey;
          strcpy(begin->keysarr[0].name,d);
     
        begin->pointers[0] = uproot;
        begin->pointers[1] = nodejs;}
}





void searchkey(int key){

    int pos, i, n;
    struct node *qr =begin;
    printf("searchpath:\n");
    while (qr!=NULL){
     n = qr->n;
           for (i=0; i < qr->n; i++){
              printf(" %d ",qr->keysarr[i].id);
              printf(" %s ",qr->keysarr[i].name);}
              
        printf("\n");
        
           pos = locate(key, qr->keysarr, n);
            if (pos < n && key == qr->keysarr[pos].id){
                  
                  return;}
     qr = qr->pointers[pos];}
    
    printf("Key=%d is not found\n",key);
}

char* locatestr(int key){

    int pos, i, n;
    char *str;
    strcpy(str," ");
    struct node *qr = begin;
    while (qr!=NULL)
    {
          n = qr->n;
          pos = locate(key, qr->keysarr, n);
       if (pos < n && key == qr->keysarr[pos].id){
            strcpy(str,qr->keysarr[pos].name);
            return str;}
       qr = qr->pointers[pos];
    }
   
   return str;}


enum SoK del(struct node *potr, int key,char *d)
{
    int pos, i, pivot, n ,min, nkey;
    struct array1 *key_arr;
    enum SoK value;
    struct node **p,*leftptr,*rightptr;
    
    if (potr == NULL){
      
        return nokeyfound;}
    
    n=potr->n;
    key_arr = potr->keysarr;
    p = potr->pointers;
    min = (order - 1)/2;
     
    
    pos = locate(key, key_arr, n);

    if (p[0] == NULL)
    {
    
        if (pos == n || key < key_arr[pos].id){
            
            return nokeyfound;}
        
        for (i=pos+1; i < n; i++)
        {
            key_arr[i-1].id = key_arr[i].id;
           strcpy( key_arr[i-1].name , key_arr[i].name);
            p[i] = p[i+1];
        }
        return --potr->n >= (potr==begin ? 1 : min) ? triumph : Mergecase;
    }

   
    if (pos < n && key == key_arr[pos].id)
    {
        struct node *qp = p[pos], *qp1;
      
        while(1)
        {
            nkey = qp->n;
            qp1 = qp->pointers[nkey];
            if (qp1 == NULL)
                break;
            qp = qp1;
        }
        key_arr[pos].id = qp->keysarr[nkey-1].id;
      strcpy(  key_arr[pos].name, qp->keysarr[nkey-1].name);
        qp->keysarr[nkey - 1].id = key;
        strcpy(qp->keysarr[nkey - 1].name,d);
    }
    value = del(p[pos], key,d);
    if (value != Mergecase)
        return value;

    if (pos > 0 && p[pos-1]->n > min)
    {
        pivot = pos - 1; 
        leftptr = p[pivot];
        rightptr = p[pos];
        
        rightptr->pointers[rightptr->n + 1] = rightptr->pointers[rightptr->n];
        for (i=rightptr->n; i>0; i--)
        {
            rightptr->keysarr[i].id = rightptr->keysarr[i-1].id;
           strcpy( rightptr->keysarr[i].name , rightptr->keysarr[i-1].name);
            rightptr->pointers[i] = rightptr->pointers[i-1];
        }
        rightptr->n++;
        rightptr->keysarr[0].id = key_arr[pivot].id;
        strcpy( rightptr->keysarr[0].name , key_arr[pivot].name);
        rightptr->pointers[0] = leftptr->pointers[leftptr->n];
        key_arr[pivot].id = leftptr->keysarr[--leftptr->n].id;
       strcpy( key_arr[pivot].name , leftptr->keysarr[leftptr->n].name);
        return triumph;
    }

    if (pos < n && p[pos + 1]->n > min)
    {
        pivot = pos; 
        leftptr = p[pivot];
        rightptr = p[pivot+1];
       
        leftptr->keysarr[leftptr->n].id= key_arr[pivot].id;
        strcpy(leftptr->keysarr[leftptr->n].name, key_arr[pivot].name);
        leftptr->pointers[leftptr->n + 1] = rightptr->pointers[0];
        key_arr[pivot].id= rightptr->keysarr[0].id;
        strcpy(key_arr[pivot].name, rightptr->keysarr[0].name);
        leftptr->n++;
        rightptr->n--;
        for (i=0; i < rightptr->n; i++)
        {
            rightptr->keysarr[i].id = rightptr->keysarr[i+1].id;
            strcpy(rightptr->keysarr[i].name,rightptr->keysarr[i+1].name);
            rightptr->pointers[i] = rightptr->pointers[i+1];
        }
        rightptr->pointers[rightptr->n] = rightptr->pointers[rightptr->n + 1];
        return triumph;
    }

    if(pos == n)
        pivot = pos-1;
    else
        pivot = pos;

    leftptr = p[pivot];
    rightptr = p[pivot+1];
   
    leftptr->keysarr[leftptr->n].id = key_arr[pivot].id;
    strcpy( leftptr->keysarr[leftptr->n].name , key_arr[pivot].name);
    leftptr->pointers[leftptr->n + 1] = rightptr->pointers[0];
    for (i=0; i < rightptr->n; i++)
    {
        leftptr->keysarr[leftptr->n + 1 + i].id = rightptr->keysarr[i].id;
        strcpy(leftptr->keysarr[leftptr->n + 1 + i].name , rightptr->keysarr[i].name);
        leftptr->pointers[leftptr->n + 2 + i] = rightptr->pointers[i+1];
    }
    leftptr->n = leftptr->n + rightptr->n +1;
    free(rightptr); 
    for (i=pos+1; i < n; i++)
    {
        key_arr[i-1].id = key_arr[i].id;
       strcpy( key_arr[i-1].name , key_arr[i].name);
        p[i] = p[i+1];
    }
    return --potr->n >= (potr == begin ? 1 : min) ? triumph : Mergecase;
}









void DeleteKey(int key)
{
    struct node *uproot;
    enum SoK value;
    char d[100];
    strcpy(d,locatestr(key));
    value = del(begin,key,d);
    switch (value)
    {
    case nokeyfound:
        printf("Key=%d is not available\n",key);
        break;
    case Mergecase:
        uproot = begin;
        begin = begin->pointers[0];
        free(uproot);
        break;
    }
}

int main(int argc,char *argv[]){

    int n,p,a,flag=0,k1;
    char str[100],opn;
    if(argc!=2){
       printf("Invalid input\n");
    return 0;}
    FILE *input;
   input=fopen(argv[1],"r");
   fscanf(input,"%d",&order);
   fscanf(input,"%c",&opn);
while(1){
   if(fscanf(input,"%d %s",&p,str)==EOF)
             break;
   insert(p,str);
   fscanf(input,"%c",&opn);
}
    
 while(1)
    {
        printf("a.Search\n");
        printf("b.Insert\n");
        printf("c.Delete\n");
        printf("d.Quit\n");
        printf("Enter your operation : ");
        scanf("%c",&opn); 
        getchar();
         if(opn=='a'){
           printf("Enter Key: ");
             scanf("%d",&k1);getchar();
             searchkey(k1);
         }
         else if(opn=='b'){
            printf("Enter Key and name: ");
            scanf("%d",&k1);getchar();
            scanf("%s",str);getchar();
            insert(k1,str);
            searchkey(k1);
         }
         else if(opn=='c'){
            printf("Enter the Key: ");
            scanf("%d",&k1);getchar();
            DeleteKey(k1);
         }
         else if(opn=='d'){
             return 0;
         }
         else
         {
           printf("Invalid option\n");
         }
        
    }
    return 0;}



